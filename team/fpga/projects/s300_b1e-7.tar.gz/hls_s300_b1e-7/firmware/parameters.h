#ifndef PARAMETERS_H_
#define PARAMETERS_H_

#include "ap_fixed.h"
#include "ap_int.h"

#include "nnet_utils/nnet_code_gen.h"
#include "nnet_utils/nnet_helpers.h"
// hls-fpga-machine-learning insert includes
#include "nnet_utils/nnet_activation.h"
#include "nnet_utils/nnet_activation_stream.h"
#include "nnet_utils/nnet_dense.h"
#include "nnet_utils/nnet_einsum.h"
#include "nnet_utils/nnet_einsum_dense.h"
#include "nnet_utils/nnet_merge.h"
#include "nnet_utils/nnet_merge_stream.h"
#include "nnet_utils/nnet_pooling.h"
#include "nnet_utils/nnet_pooling_stream.h"

// hls-fpga-machine-learning insert weights
#include "weights/b3.h"
#include "weights/b6.h"
#include "weights/b9.h"
#include "weights/b12.h"
#include "weights/b19.h"
#include "weights/b24.h"
#include "weights/b27.h"


// hls-fpga-machine-learning insert layer-config
// embed
struct config3_tpose_inp {
    static const unsigned dims = 2;
    static const unsigned N = 176;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config3_tpose_inp_from_shape[2] = {16, 11};
unsigned config3_tpose_inp_to_shape[2] = {16, 11};
unsigned config3_tpose_inp_perm[2] = {0, 1};
unsigned config3_tpose_inp_perm_strides[2] = {11, 1};

const unsigned* const config3_tpose_inp::from_shape = config3_tpose_inp_from_shape;
const unsigned* const config3_tpose_inp::to_shape = config3_tpose_inp_to_shape;
const unsigned* const config3_tpose_inp::perm = config3_tpose_inp_perm;
const unsigned* const config3_tpose_inp::perm_strides = config3_tpose_inp_perm_strides;


struct config3_tpose_out {
    static const unsigned dims = 2;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config3_tpose_out_from_shape[2] = {16, 16};
unsigned config3_tpose_out_to_shape[2] = {16, 16};
unsigned config3_tpose_out_perm[2] = {0, 1};
unsigned config3_tpose_out_perm_strides[2] = {16, 1};

const unsigned* const config3_tpose_out::from_shape = config3_tpose_out_from_shape;
const unsigned* const config3_tpose_out::to_shape = config3_tpose_out_to_shape;
const unsigned* const config3_tpose_out::perm = config3_tpose_out_perm;
const unsigned* const config3_tpose_out::perm_strides = config3_tpose_out_perm_strides;



struct config3 {
    typedef config3_tpose_inp tpose_inp_conf;
    typedef config3_tpose_out tpose_out_conf;

    typedef embed_accum_t accum_t;
    typedef embed_bias_t bias_t;

    constexpr static auto da_kernel = nnet::einsum_dense3_da_kernel<embed_iq_t, accum_t>;

    // Layer Sizes
    static const unsigned n_free_data = 16;
    static const unsigned n_free_kernel = 16;
    static const unsigned n_contract = 11;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::distributed_arithmetic;
    static const unsigned reuse_factor = 1;
    static const unsigned parallelization_factor = 16; // Only useful when n_inplace > 1
};

// embed_relu
struct relu_config4 : nnet::activ_config {
    static const unsigned n_in = 256;
    static const unsigned table_size = 8388608;
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned reuse_factor = 1;
    typedef embed_relu_table_t table_t;
};

// mha0_query
struct config6_tpose_inp {
    static const unsigned dims = 2;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config6_tpose_inp_from_shape[2] = {16, 16};
unsigned config6_tpose_inp_to_shape[2] = {16, 16};
unsigned config6_tpose_inp_perm[2] = {0, 1};
unsigned config6_tpose_inp_perm_strides[2] = {16, 1};

const unsigned* const config6_tpose_inp::from_shape = config6_tpose_inp_from_shape;
const unsigned* const config6_tpose_inp::to_shape = config6_tpose_inp_to_shape;
const unsigned* const config6_tpose_inp::perm = config6_tpose_inp_perm;
const unsigned* const config6_tpose_inp::perm_strides = config6_tpose_inp_perm_strides;


struct config6_tpose_out {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config6_tpose_out_from_shape[3] = {16, 1, 16};
unsigned config6_tpose_out_to_shape[3] = {16, 1, 16};
unsigned config6_tpose_out_perm[3] = {0, 1, 2};
unsigned config6_tpose_out_perm_strides[3] = {16, 16, 1};

const unsigned* const config6_tpose_out::from_shape = config6_tpose_out_from_shape;
const unsigned* const config6_tpose_out::to_shape = config6_tpose_out_to_shape;
const unsigned* const config6_tpose_out::perm = config6_tpose_out_perm;
const unsigned* const config6_tpose_out::perm_strides = config6_tpose_out_perm_strides;



struct config6 {
    typedef config6_tpose_inp tpose_inp_conf;
    typedef config6_tpose_out tpose_out_conf;

    typedef mha0_query_accum_t accum_t;
    typedef mha0_query_bias_t bias_t;

    constexpr static auto da_kernel = nnet::einsum_dense6_da_kernel<mha0_query_iq_t, accum_t>;

    // Layer Sizes
    static const unsigned n_free_data = 16;
    static const unsigned n_free_kernel = 16;
    static const unsigned n_contract = 16;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::distributed_arithmetic;
    static const unsigned reuse_factor = 1;
    static const unsigned parallelization_factor = 16; // Only useful when n_inplace > 1
};

// mha0_key
struct config9_tpose_inp {
    static const unsigned dims = 2;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config9_tpose_inp_from_shape[2] = {16, 16};
unsigned config9_tpose_inp_to_shape[2] = {16, 16};
unsigned config9_tpose_inp_perm[2] = {0, 1};
unsigned config9_tpose_inp_perm_strides[2] = {16, 1};

const unsigned* const config9_tpose_inp::from_shape = config9_tpose_inp_from_shape;
const unsigned* const config9_tpose_inp::to_shape = config9_tpose_inp_to_shape;
const unsigned* const config9_tpose_inp::perm = config9_tpose_inp_perm;
const unsigned* const config9_tpose_inp::perm_strides = config9_tpose_inp_perm_strides;


struct config9_tpose_out {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config9_tpose_out_from_shape[3] = {16, 1, 16};
unsigned config9_tpose_out_to_shape[3] = {16, 1, 16};
unsigned config9_tpose_out_perm[3] = {0, 1, 2};
unsigned config9_tpose_out_perm_strides[3] = {16, 16, 1};

const unsigned* const config9_tpose_out::from_shape = config9_tpose_out_from_shape;
const unsigned* const config9_tpose_out::to_shape = config9_tpose_out_to_shape;
const unsigned* const config9_tpose_out::perm = config9_tpose_out_perm;
const unsigned* const config9_tpose_out::perm_strides = config9_tpose_out_perm_strides;



struct config9 {
    typedef config9_tpose_inp tpose_inp_conf;
    typedef config9_tpose_out tpose_out_conf;

    typedef mha0_key_accum_t accum_t;
    typedef mha0_key_bias_t bias_t;

    constexpr static auto da_kernel = nnet::einsum_dense9_da_kernel<mha0_key_iq_t, accum_t>;

    // Layer Sizes
    static const unsigned n_free_data = 16;
    static const unsigned n_free_kernel = 16;
    static const unsigned n_contract = 16;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::distributed_arithmetic;
    static const unsigned reuse_factor = 1;
    static const unsigned parallelization_factor = 16; // Only useful when n_inplace > 1
};

// mha0_value
struct config12_tpose_inp {
    static const unsigned dims = 2;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config12_tpose_inp_from_shape[2] = {16, 16};
unsigned config12_tpose_inp_to_shape[2] = {16, 16};
unsigned config12_tpose_inp_perm[2] = {0, 1};
unsigned config12_tpose_inp_perm_strides[2] = {16, 1};

const unsigned* const config12_tpose_inp::from_shape = config12_tpose_inp_from_shape;
const unsigned* const config12_tpose_inp::to_shape = config12_tpose_inp_to_shape;
const unsigned* const config12_tpose_inp::perm = config12_tpose_inp_perm;
const unsigned* const config12_tpose_inp::perm_strides = config12_tpose_inp_perm_strides;


struct config12_tpose_out {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config12_tpose_out_from_shape[3] = {16, 1, 16};
unsigned config12_tpose_out_to_shape[3] = {16, 1, 16};
unsigned config12_tpose_out_perm[3] = {0, 1, 2};
unsigned config12_tpose_out_perm_strides[3] = {16, 16, 1};

const unsigned* const config12_tpose_out::from_shape = config12_tpose_out_from_shape;
const unsigned* const config12_tpose_out::to_shape = config12_tpose_out_to_shape;
const unsigned* const config12_tpose_out::perm = config12_tpose_out_perm;
const unsigned* const config12_tpose_out::perm_strides = config12_tpose_out_perm_strides;



struct config12 {
    typedef config12_tpose_inp tpose_inp_conf;
    typedef config12_tpose_out tpose_out_conf;

    typedef mha0_value_accum_t accum_t;
    typedef mha0_value_bias_t bias_t;

    constexpr static auto da_kernel = nnet::einsum_dense12_da_kernel<mha0_value_iq_t, accum_t>;

    // Layer Sizes
    static const unsigned n_free_data = 16;
    static const unsigned n_free_kernel = 16;
    static const unsigned n_contract = 16;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::distributed_arithmetic;
    static const unsigned reuse_factor = 1;
    static const unsigned parallelization_factor = 16; // Only useful when n_inplace > 1
};

// mha0_mha0_QK
struct config14_tpose_inp0 {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config14_tpose_inp0_from_shape[3] = {16, 1, 16};
unsigned config14_tpose_inp0_to_shape[3] = {1, 16, 16};
unsigned config14_tpose_inp0_perm[3] = {1, 0, 2};
unsigned config14_tpose_inp0_perm_strides[3] = {16, 16, 1};

const unsigned* const config14_tpose_inp0::from_shape = config14_tpose_inp0_from_shape;
const unsigned* const config14_tpose_inp0::to_shape = config14_tpose_inp0_to_shape;
const unsigned* const config14_tpose_inp0::perm = config14_tpose_inp0_perm;
const unsigned* const config14_tpose_inp0::perm_strides = config14_tpose_inp0_perm_strides;


struct config14_tpose_inp1 {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config14_tpose_inp1_from_shape[3] = {16, 1, 16};
unsigned config14_tpose_inp1_to_shape[3] = {1, 16, 16};
unsigned config14_tpose_inp1_perm[3] = {1, 0, 2};
unsigned config14_tpose_inp1_perm_strides[3] = {16, 16, 1};

const unsigned* const config14_tpose_inp1::from_shape = config14_tpose_inp1_from_shape;
const unsigned* const config14_tpose_inp1::to_shape = config14_tpose_inp1_to_shape;
const unsigned* const config14_tpose_inp1::perm = config14_tpose_inp1_perm;
const unsigned* const config14_tpose_inp1::perm_strides = config14_tpose_inp1_perm_strides;


struct config14_tpose_out {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config14_tpose_out_from_shape[3] = {1, 16, 16};
unsigned config14_tpose_out_to_shape[3] = {1, 16, 16};
unsigned config14_tpose_out_perm[3] = {0, 2, 1};
unsigned config14_tpose_out_perm_strides[3] = {256, 1, 16};

const unsigned* const config14_tpose_out::from_shape = config14_tpose_out_from_shape;
const unsigned* const config14_tpose_out::to_shape = config14_tpose_out_to_shape;
const unsigned* const config14_tpose_out::perm = config14_tpose_out_perm;
const unsigned* const config14_tpose_out::perm_strides = config14_tpose_out_perm_strides;



struct config14 {
    typedef config14_tpose_inp0 tpose_inp0_config;
    typedef config14_tpose_inp1 tpose_inp1_config;
    typedef config14_tpose_out tpose_out_conf;

    typedef mha0_mha0_QK_accum_t accum_t;

    // Layer Sizes
    static const unsigned n_free0 = 16;
    static const unsigned n_free1 = 16;
    static const unsigned n_contract = 16;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::latency;
    static const unsigned reuse_factor = 1;
    static const unsigned multiplier_limit = 4096;
    static const bool store_weights_in_bram = false; // NOT USED

    template <class x_T, class y_T>
    using product = nnet::product::mult<x_T, y_T>;
};

// mha0_q_softmax
struct softmax_config15 : nnet::activ_config {
    static const unsigned n_in = 256;
    static const unsigned n_slice = 16;
    static const unsigned n_outer = 16;
    static const unsigned n_inner = 1;
    static const unsigned parallelization_factor = 16;
    static const unsigned exp_table_size = 512;
    static const unsigned inv_table_size = 1024;
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned reuse_factor = 1;
    static const unsigned axis = -1;
    static const nnet::softmax_implementation implementation = nnet::softmax_implementation::stable;
    static constexpr float exp_scale = 0.25;
    typedef mha0_q_softmax_exp_table_t exp_table_t;
    typedef mha0_q_softmax_inv_table_t inv_table_t;
    typedef mha0_q_softmax_accum_t accum_t;
    typedef mha0_q_softmax_inv_inp_t inv_inp_t;
    typedef mha0_q_softmax_inp_norm_t inp_norm_t;
};

// mha0_mha0_aV
struct config17_tpose_inp0 {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config17_tpose_inp0_from_shape[3] = {1, 16, 16};
unsigned config17_tpose_inp0_to_shape[3] = {1, 16, 16};
unsigned config17_tpose_inp0_perm[3] = {0, 1, 2};
unsigned config17_tpose_inp0_perm_strides[3] = {256, 16, 1};

const unsigned* const config17_tpose_inp0::from_shape = config17_tpose_inp0_from_shape;
const unsigned* const config17_tpose_inp0::to_shape = config17_tpose_inp0_to_shape;
const unsigned* const config17_tpose_inp0::perm = config17_tpose_inp0_perm;
const unsigned* const config17_tpose_inp0::perm_strides = config17_tpose_inp0_perm_strides;


struct config17_tpose_inp1 {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config17_tpose_inp1_from_shape[3] = {16, 1, 16};
unsigned config17_tpose_inp1_to_shape[3] = {1, 16, 16};
unsigned config17_tpose_inp1_perm[3] = {1, 2, 0};
unsigned config17_tpose_inp1_perm_strides[3] = {16, 1, 16};

const unsigned* const config17_tpose_inp1::from_shape = config17_tpose_inp1_from_shape;
const unsigned* const config17_tpose_inp1::to_shape = config17_tpose_inp1_to_shape;
const unsigned* const config17_tpose_inp1::perm = config17_tpose_inp1_perm;
const unsigned* const config17_tpose_inp1::perm_strides = config17_tpose_inp1_perm_strides;


struct config17_tpose_out {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config17_tpose_out_from_shape[3] = {1, 16, 16};
unsigned config17_tpose_out_to_shape[3] = {16, 1, 16};
unsigned config17_tpose_out_perm[3] = {1, 0, 2};
unsigned config17_tpose_out_perm_strides[3] = {16, 256, 1};

const unsigned* const config17_tpose_out::from_shape = config17_tpose_out_from_shape;
const unsigned* const config17_tpose_out::to_shape = config17_tpose_out_to_shape;
const unsigned* const config17_tpose_out::perm = config17_tpose_out_perm;
const unsigned* const config17_tpose_out::perm_strides = config17_tpose_out_perm_strides;



struct config17 {
    typedef config17_tpose_inp0 tpose_inp0_config;
    typedef config17_tpose_inp1 tpose_inp1_config;
    typedef config17_tpose_out tpose_out_conf;

    typedef mha0_mha0_aV_accum_t accum_t;

    // Layer Sizes
    static const unsigned n_free0 = 16;
    static const unsigned n_free1 = 16;
    static const unsigned n_contract = 16;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::latency;
    static const unsigned reuse_factor = 1;
    static const unsigned multiplier_limit = 4096;
    static const bool store_weights_in_bram = false; // NOT USED

    template <class x_T, class y_T>
    using product = nnet::product::mult<x_T, y_T>;
};

// mha0_attention_output
struct config19_tpose_inp {
    static const unsigned dims = 3;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config19_tpose_inp_from_shape[3] = {16, 1, 16};
unsigned config19_tpose_inp_to_shape[3] = {16, 1, 16};
unsigned config19_tpose_inp_perm[3] = {0, 1, 2};
unsigned config19_tpose_inp_perm_strides[3] = {16, 16, 1};

const unsigned* const config19_tpose_inp::from_shape = config19_tpose_inp_from_shape;
const unsigned* const config19_tpose_inp::to_shape = config19_tpose_inp_to_shape;
const unsigned* const config19_tpose_inp::perm = config19_tpose_inp_perm;
const unsigned* const config19_tpose_inp::perm_strides = config19_tpose_inp_perm_strides;


struct config19_tpose_out {
    static const unsigned dims = 2;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config19_tpose_out_from_shape[2] = {16, 16};
unsigned config19_tpose_out_to_shape[2] = {16, 16};
unsigned config19_tpose_out_perm[2] = {0, 1};
unsigned config19_tpose_out_perm_strides[2] = {16, 1};

const unsigned* const config19_tpose_out::from_shape = config19_tpose_out_from_shape;
const unsigned* const config19_tpose_out::to_shape = config19_tpose_out_to_shape;
const unsigned* const config19_tpose_out::perm = config19_tpose_out_perm;
const unsigned* const config19_tpose_out::perm_strides = config19_tpose_out_perm_strides;



struct config19 {
    typedef config19_tpose_inp tpose_inp_conf;
    typedef config19_tpose_out tpose_out_conf;

    typedef mha0_attention_output_accum_t accum_t;
    typedef mha0_attention_output_bias_t bias_t;

    constexpr static auto da_kernel = nnet::einsum_dense19_da_kernel<mha0_attention_output_iq_t, accum_t>;

    // Layer Sizes
    static const unsigned n_free_data = 16;
    static const unsigned n_free_kernel = 16;
    static const unsigned n_contract = 16;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::distributed_arithmetic;
    static const unsigned reuse_factor = 1;
    static const unsigned parallelization_factor = 16; // Only useful when n_inplace > 1
};

// res_attn0
struct config22 : nnet::merge_config {
    static const unsigned n_elem = 16*16;
    static const unsigned n_elem1 = 16*16;
    static const unsigned n_elem2 = 16*16;
    static const unsigned reuse_factor = 1;
};

// mlp0_0
struct config24_tpose_inp {
    static const unsigned dims = 2;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config24_tpose_inp_from_shape[2] = {16, 16};
unsigned config24_tpose_inp_to_shape[2] = {16, 16};
unsigned config24_tpose_inp_perm[2] = {0, 1};
unsigned config24_tpose_inp_perm_strides[2] = {16, 1};

const unsigned* const config24_tpose_inp::from_shape = config24_tpose_inp_from_shape;
const unsigned* const config24_tpose_inp::to_shape = config24_tpose_inp_to_shape;
const unsigned* const config24_tpose_inp::perm = config24_tpose_inp_perm;
const unsigned* const config24_tpose_inp::perm_strides = config24_tpose_inp_perm_strides;


struct config24_tpose_out {
    static const unsigned dims = 2;
    static const unsigned N = 512;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config24_tpose_out_from_shape[2] = {16, 32};
unsigned config24_tpose_out_to_shape[2] = {16, 32};
unsigned config24_tpose_out_perm[2] = {0, 1};
unsigned config24_tpose_out_perm_strides[2] = {32, 1};

const unsigned* const config24_tpose_out::from_shape = config24_tpose_out_from_shape;
const unsigned* const config24_tpose_out::to_shape = config24_tpose_out_to_shape;
const unsigned* const config24_tpose_out::perm = config24_tpose_out_perm;
const unsigned* const config24_tpose_out::perm_strides = config24_tpose_out_perm_strides;



struct config24 {
    typedef config24_tpose_inp tpose_inp_conf;
    typedef config24_tpose_out tpose_out_conf;

    typedef mlp0_0_accum_t accum_t;
    typedef mlp0_0_bias_t bias_t;

    constexpr static auto da_kernel = nnet::einsum_dense24_da_kernel<mlp0_0_iq_t, accum_t>;

    // Layer Sizes
    static const unsigned n_free_data = 16;
    static const unsigned n_free_kernel = 32;
    static const unsigned n_contract = 16;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::distributed_arithmetic;
    static const unsigned reuse_factor = 1;
    static const unsigned parallelization_factor = 16; // Only useful when n_inplace > 1
};

// mlp0_0_relu
struct relu_config25 : nnet::activ_config {
    static const unsigned n_in = 512;
    static const unsigned table_size = 1048576;
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned reuse_factor = 1;
    typedef mlp0_0_relu_table_t table_t;
};

// mlp0_1
struct config27_tpose_inp {
    static const unsigned dims = 2;
    static const unsigned N = 512;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config27_tpose_inp_from_shape[2] = {16, 32};
unsigned config27_tpose_inp_to_shape[2] = {16, 32};
unsigned config27_tpose_inp_perm[2] = {0, 1};
unsigned config27_tpose_inp_perm_strides[2] = {32, 1};

const unsigned* const config27_tpose_inp::from_shape = config27_tpose_inp_from_shape;
const unsigned* const config27_tpose_inp::to_shape = config27_tpose_inp_to_shape;
const unsigned* const config27_tpose_inp::perm = config27_tpose_inp_perm;
const unsigned* const config27_tpose_inp::perm_strides = config27_tpose_inp_perm_strides;


struct config27_tpose_out {
    static const unsigned dims = 2;
    static const unsigned N = 256;
    static const unsigned* const from_shape;
    static const unsigned* const to_shape;
    static const unsigned* const perm;
    static const unsigned* const perm_strides;
};

unsigned config27_tpose_out_from_shape[2] = {16, 16};
unsigned config27_tpose_out_to_shape[2] = {16, 16};
unsigned config27_tpose_out_perm[2] = {0, 1};
unsigned config27_tpose_out_perm_strides[2] = {16, 1};

const unsigned* const config27_tpose_out::from_shape = config27_tpose_out_from_shape;
const unsigned* const config27_tpose_out::to_shape = config27_tpose_out_to_shape;
const unsigned* const config27_tpose_out::perm = config27_tpose_out_perm;
const unsigned* const config27_tpose_out::perm_strides = config27_tpose_out_perm_strides;



struct config27 {
    typedef config27_tpose_inp tpose_inp_conf;
    typedef config27_tpose_out tpose_out_conf;

    typedef mlp0_1_accum_t accum_t;
    typedef mlp0_1_bias_t bias_t;

    constexpr static auto da_kernel = nnet::einsum_dense27_da_kernel<mlp0_1_iq_t, accum_t>;

    // Layer Sizes
    static const unsigned n_free_data = 16;
    static const unsigned n_free_kernel = 16;
    static const unsigned n_contract = 32;
    static const unsigned n_inplace = 1;

    // Resource reuse info
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned strategy = nnet::distributed_arithmetic;
    static const unsigned reuse_factor = 1;
    static const unsigned parallelization_factor = 16; // Only useful when n_inplace > 1
};

// res_mlp0
struct config30 : nnet::merge_config {
    static const unsigned n_elem = 16*16;
    static const unsigned n_elem1 = 16*16;
    static const unsigned n_elem2 = 16*16;
    static const unsigned reuse_factor = 1;
};

// mean_pool
struct config32 : nnet::pooling1d_config {
    static const unsigned n_in = 16;
    static const unsigned n_filt = 16;
    static const nnet::Pool_Op pool_op = nnet::Average;
    static const unsigned reuse_factor = 1;
    typedef mean_pool_accum_t accum_t;
};

// max_pool
struct config34 : nnet::pooling1d_config {
    static const unsigned n_in = 16;
    static const unsigned n_filt = 16;
    static const nnet::Pool_Op pool_op = nnet::Max;
    static const unsigned reuse_factor = 1;
    typedef max_pool_accum_t accum_t;
};

// concat0
struct config35 : nnet::concat_config {
    static const unsigned n_elem1_0 = 16;
    static const unsigned n_elem1_1 = 0;
    static const unsigned n_elem1_2 = 0;
    static const unsigned n_elem2_0 = 16;
    static const unsigned n_elem2_1 = 0;
    static const unsigned n_elem2_2 = 0;

    static const int axis = -1;
};

// concat1
struct config37 : nnet::concat_config {
    static const unsigned n_elem1_0 = 32;
    static const unsigned n_elem1_1 = 0;
    static const unsigned n_elem1_2 = 0;
    static const unsigned n_elem2_0 = 11;
    static const unsigned n_elem2_1 = 0;
    static const unsigned n_elem2_2 = 0;

    static const int axis = -1;
};

// head0_relu
struct relu_config40 : nnet::activ_config {
    static const unsigned n_in = 16;
    static const unsigned table_size = 1048576;
    static const unsigned io_type = nnet::io_parallel;
    static const unsigned reuse_factor = 1;
    typedef head0_relu_table_t table_t;
};



#endif
