#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <array>
#include <cstddef>
#include <cstdio>
#include <tuple>
#include <tuple>


// hls-fpga-machine-learning insert numbers

// hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<12,3> particles_t;
typedef ap_fixed<11,3> embed_iq_t;
typedef ap_fixed<23,7> embed_accum_t;
typedef ap_fixed<15,7> embed_t;
typedef ap_fixed<15,-1> embed_bias_t;
typedef ap_fixed<12,4> embed_relu_t;
typedef ap_fixed<18,8> embed_relu_table_t;
typedef ap_fixed<9,4> mha0_query_iq_t;
typedef ap_fixed<17,6> mha0_query_accum_t;
typedef ap_fixed<9,5> mha0_query_t;
typedef ap_fixed<11,0> mha0_query_bias_t;
typedef ap_fixed<8,5> mha0_query_oq_t;
typedef ap_fixed<9,4> mha0_key_iq_t;
typedef ap_fixed<15,6> mha0_key_accum_t;
typedef ap_fixed<9,4> mha0_key_t;
typedef ap_ufixed<2,32> mha0_key_bias_t;
typedef ap_fixed<8,4> mha0_key_oq_t;
typedef ap_fixed<9,4> mha0_value_iq_t;
typedef ap_fixed<21,5> mha0_value_accum_t;
typedef ap_fixed<10,3> mha0_value_t;
typedef ap_fixed<13,-3> mha0_value_bias_t;
typedef ap_fixed<9,3> mha0_value_oq_t;
typedef ap_fixed<17,10> mha0_mha0_QK_accum_t;
typedef ap_fixed<17,10> mha0_mha0_QK_t;
typedef ap_ufixed<6,2,AP_RND_CONV,AP_SAT,0> mha0_q_softmax_exp_table_t;
typedef ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0> mha0_q_softmax_inv_table_t;
typedef ap_fixed<10,5,AP_RND,AP_WRAP,0> mha0_q_softmax_inv_inp_t;
typedef ap_fixed<9,4,AP_RND,AP_SAT,0> mha0_q_softmax_inp_norm_t;
typedef ap_fixed<17,5> mha0_q_softmax_accum_t;
typedef ap_fixed<7,0> mha0_q_softmax_t;
typedef ap_fixed<18,8> mha0_q_softmax_table_t;
typedef ap_fixed<6,0> mha0_q_softmax_oq_t;
typedef ap_fixed<17,6> mha0_mha0_aV_accum_t;
typedef ap_fixed<9,2> mha0_mha0_aV_t;
typedef ap_fixed<8,2> mha0_attention_output_iq_t;
typedef ap_fixed<16,4> mha0_attention_output_accum_t;
typedef ap_fixed<10,2> mha0_attention_output_t;
typedef ap_fixed<11,-1> mha0_attention_output_bias_t;
typedef ap_fixed<10,3> quantizer_t;
typedef ap_fixed<9,2> quantizer_1_t;
typedef ap_fixed<11,4> res_attn0_t;
typedef ap_fixed<10,4> mlp0_0_iq_t;
typedef ap_fixed<20,6> mlp0_0_accum_t;
typedef ap_fixed<13,6> mlp0_0_t;
typedef ap_fixed<14,0> mlp0_0_bias_t;
typedef ap_fixed<10,3> mlp0_0_relu_t;
typedef ap_fixed<18,8> mlp0_0_relu_table_t;
typedef ap_fixed<9,3> mlp0_1_iq_t;
typedef ap_fixed<20,6> mlp0_1_accum_t;
typedef ap_fixed<11,4> mlp0_1_t;
typedef ap_fixed<13,-1> mlp0_1_bias_t;
typedef ap_fixed<10,4> quantizer_2_t;
typedef ap_fixed<10,4> quantizer_3_t;
typedef ap_fixed<10,4> res_mlp0_t;
typedef ap_fixed<9,4> mean_pool_iq_t;
typedef ap_fixed<17,8> mean_pool_accum_t;
typedef ap_fixed<10,3> mean_pool_t;
typedef ap_fixed<10,4> max_pool_iq_t;
typedef ap_fixed<10,4> max_pool_accum_t;
typedef ap_fixed<10,4> max_pool_t;
typedef ap_fixed<11,4> concat0_t;
typedef ap_fixed<12,4> event_t;
typedef ap_fixed<12,4> concat1_t;
typedef ap_fixed<20,7> head0_accum_t;
typedef ap_fixed<14,7> head0_t;
typedef ap_uint<1> layer39_index;
typedef ap_fixed<12,5> head0_relu_t;
typedef ap_fixed<18,8> head0_relu_table_t;
typedef ap_fixed<20,8> logit_accum_t;
typedef ap_fixed<20,8> result_t;
typedef ap_uint<1> layer42_index;

// hls-fpga-machine-learning insert emulator-defines


#endif
