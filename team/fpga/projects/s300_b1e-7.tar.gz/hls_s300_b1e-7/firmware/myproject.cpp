#include <iostream>

#include "myproject.h"
#include "parameters.h"


void myproject(
    particles_t particles[16*11], event_t event[11],
    result_t layer42_out[1]
) {

    // hls-fpga-machine-learning insert IO
    #pragma HLS ARRAY_RESHAPE variable=particles complete dim=0
    #pragma HLS ARRAY_RESHAPE variable=event complete dim=0
    #pragma HLS ARRAY_PARTITION variable=layer42_out complete dim=0
    #pragma HLS INTERFACE ap_vld port=particles,event,layer42_out 
    #pragma HLS PIPELINE

    // hls-fpga-machine-learning insert load weights
#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        nnet::load_weights_from_txt<embed_bias_t, 256>(b3, "b3.txt");
        nnet::load_weights_from_txt<mha0_query_bias_t, 256>(b6, "b6.txt");
        nnet::load_weights_from_txt<mha0_key_bias_t, 256>(b9, "b9.txt");
        nnet::load_weights_from_txt<mha0_value_bias_t, 256>(b12, "b12.txt");
        nnet::load_weights_from_txt<mha0_attention_output_bias_t, 256>(b19, "b19.txt");
        nnet::load_weights_from_txt<mlp0_0_bias_t, 512>(b24, "b24.txt");
        nnet::load_weights_from_txt<mlp0_1_bias_t, 256>(b27, "b27.txt");
        loaded_weights = true;    }
#endif
    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    embed_iq_t layer2_out[16*11];
    #pragma HLS ARRAY_PARTITION variable=layer2_out complete dim=0

    embed_t layer3_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer3_out complete dim=0

    embed_relu_t layer4_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer4_out complete dim=0

    mha0_query_iq_t layer5_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer5_out complete dim=0

    mha0_query_t layer6_out[16*1*16];
    #pragma HLS ARRAY_PARTITION variable=layer6_out complete dim=0

    mha0_query_oq_t layer7_out[16*1*16];
    #pragma HLS ARRAY_PARTITION variable=layer7_out complete dim=0

    mha0_key_iq_t layer8_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer8_out complete dim=0

    mha0_key_t layer9_out[16*1*16];
    #pragma HLS ARRAY_PARTITION variable=layer9_out complete dim=0

    mha0_key_oq_t layer10_out[16*1*16];
    #pragma HLS ARRAY_PARTITION variable=layer10_out complete dim=0

    mha0_value_iq_t layer11_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer11_out complete dim=0

    mha0_value_t layer12_out[16*1*16];
    #pragma HLS ARRAY_PARTITION variable=layer12_out complete dim=0

    mha0_value_oq_t layer13_out[16*1*16];
    #pragma HLS ARRAY_PARTITION variable=layer13_out complete dim=0

    mha0_mha0_QK_t layer14_out[1*16*16];
    #pragma HLS ARRAY_PARTITION variable=layer14_out complete dim=0

    mha0_q_softmax_t layer15_out[1*16*16];
    #pragma HLS ARRAY_PARTITION variable=layer15_out complete dim=0

    mha0_q_softmax_oq_t layer16_out[1*16*16];
    #pragma HLS ARRAY_PARTITION variable=layer16_out complete dim=0

    mha0_mha0_aV_t layer17_out[16*1*16];
    #pragma HLS ARRAY_PARTITION variable=layer17_out complete dim=0

    mha0_attention_output_iq_t layer18_out[16*1*16];
    #pragma HLS ARRAY_PARTITION variable=layer18_out complete dim=0

    mha0_attention_output_t layer19_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer19_out complete dim=0

    quantizer_t layer20_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer20_out complete dim=0

    quantizer_1_t layer21_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer21_out complete dim=0

    res_attn0_t layer22_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer22_out complete dim=0

    mlp0_0_iq_t layer23_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer23_out complete dim=0

    mlp0_0_t layer24_out[16*32];
    #pragma HLS ARRAY_PARTITION variable=layer24_out complete dim=0

    mlp0_0_relu_t layer25_out[16*32];
    #pragma HLS ARRAY_PARTITION variable=layer25_out complete dim=0

    mlp0_1_iq_t layer26_out[16*32];
    #pragma HLS ARRAY_PARTITION variable=layer26_out complete dim=0

    mlp0_1_t layer27_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer27_out complete dim=0

    quantizer_2_t layer28_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer28_out complete dim=0

    quantizer_3_t layer29_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer29_out complete dim=0

    res_mlp0_t layer30_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer30_out complete dim=0

    mean_pool_iq_t layer31_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer31_out complete dim=0

    mean_pool_t layer32_out[16];
    #pragma HLS ARRAY_PARTITION variable=layer32_out complete dim=0

    max_pool_iq_t layer33_out[16*16];
    #pragma HLS ARRAY_PARTITION variable=layer33_out complete dim=0

    max_pool_t layer34_out[16];
    #pragma HLS ARRAY_PARTITION variable=layer34_out complete dim=0

    concat0_t layer35_out[32];
    #pragma HLS ARRAY_PARTITION variable=layer35_out complete dim=0

    concat1_t layer37_out[43];
    #pragma HLS ARRAY_PARTITION variable=layer37_out complete dim=0

    head0_t layer39_out[16];
    #pragma HLS ARRAY_PARTITION variable=layer39_out complete dim=0

    head0_relu_t layer40_out[16];
    #pragma HLS ARRAY_PARTITION variable=layer40_out complete dim=0

    nnet::embed_iq<particles_t, embed_iq_t>(particles, layer2_out); // embed_iq

    nnet::einsum_dense<embed_iq_t, embed_t, config3>(layer2_out, layer3_out, b3); // embed

    nnet::relu<embed_t, embed_relu_t, relu_config4>(layer3_out, layer4_out); // embed_relu

    nnet::mha0_query_iq<embed_relu_t, mha0_query_iq_t>(layer4_out, layer5_out); // mha0_query_iq

    nnet::einsum_dense<mha0_query_iq_t, mha0_query_t, config6>(layer5_out, layer6_out, b6); // mha0_query

    nnet::mha0_query_oq<mha0_query_t, mha0_query_oq_t>(layer6_out, layer7_out); // mha0_query_oq

    nnet::mha0_key_iq<embed_relu_t, mha0_key_iq_t>(layer4_out, layer8_out); // mha0_key_iq

    nnet::einsum_dense<mha0_key_iq_t, mha0_key_t, config9>(layer8_out, layer9_out, b9); // mha0_key

    nnet::mha0_key_oq<mha0_key_t, mha0_key_oq_t>(layer9_out, layer10_out); // mha0_key_oq

    nnet::mha0_value_iq<embed_relu_t, mha0_value_iq_t>(layer4_out, layer11_out); // mha0_value_iq

    nnet::einsum_dense<mha0_value_iq_t, mha0_value_t, config12>(layer11_out, layer12_out, b12); // mha0_value

    nnet::mha0_value_oq<mha0_value_t, mha0_value_oq_t>(layer12_out, layer13_out); // mha0_value_oq

    nnet::einsum<mha0_key_oq_t, mha0_query_oq_t, mha0_mha0_QK_t, config14>(layer10_out, layer7_out, layer14_out); // mha0_mha0_QK

    nnet::softmax_multidim<mha0_mha0_QK_t, mha0_q_softmax_t, softmax_config15>(layer14_out, layer15_out); // mha0_q_softmax

    nnet::mha0_q_softmax_oq<mha0_q_softmax_t, mha0_q_softmax_oq_t>(layer15_out, layer16_out); // mha0_q_softmax_oq

    nnet::einsum<mha0_q_softmax_oq_t, mha0_value_oq_t, mha0_mha0_aV_t, config17>(layer16_out, layer13_out, layer17_out); // mha0_mha0_aV

    nnet::mha0_attention_output_iq<mha0_mha0_aV_t, mha0_attention_output_iq_t>(layer17_out, layer18_out); // mha0_attention_output_iq

    nnet::einsum_dense<mha0_attention_output_iq_t, mha0_attention_output_t, config19>(layer18_out, layer19_out, b19); // mha0_attention_output

    nnet::quantizer<embed_relu_t, quantizer_t>(layer4_out, layer20_out); // quantizer

    nnet::quantizer_1<mha0_attention_output_t, quantizer_1_t>(layer19_out, layer21_out); // quantizer_1

    nnet::add<quantizer_t, quantizer_1_t, res_attn0_t, config22>(layer20_out, layer21_out, layer22_out); // res_attn0

    nnet::mlp0_0_iq<res_attn0_t, mlp0_0_iq_t>(layer22_out, layer23_out); // mlp0_0_iq

    nnet::einsum_dense<mlp0_0_iq_t, mlp0_0_t, config24>(layer23_out, layer24_out, b24); // mlp0_0

    nnet::relu<mlp0_0_t, mlp0_0_relu_t, relu_config25>(layer24_out, layer25_out); // mlp0_0_relu

    nnet::mlp0_1_iq<mlp0_0_relu_t, mlp0_1_iq_t>(layer25_out, layer26_out); // mlp0_1_iq

    nnet::einsum_dense<mlp0_1_iq_t, mlp0_1_t, config27>(layer26_out, layer27_out, b27); // mlp0_1

    nnet::quantizer_2<res_attn0_t, quantizer_2_t>(layer22_out, layer28_out); // quantizer_2

    nnet::quantizer_3<mlp0_1_t, quantizer_3_t>(layer27_out, layer29_out); // quantizer_3

    nnet::add<quantizer_2_t, quantizer_3_t, res_mlp0_t, config30>(layer28_out, layer29_out, layer30_out); // res_mlp0

    nnet::mean_pool_iq<res_mlp0_t, mean_pool_iq_t>(layer30_out, layer31_out); // mean_pool_iq

    nnet::global_pooling1d_cl<mean_pool_iq_t, mean_pool_t, config32>(layer31_out, layer32_out); // mean_pool

    nnet::max_pool_iq<res_mlp0_t, max_pool_iq_t>(layer30_out, layer33_out); // max_pool_iq

    nnet::global_pooling1d_cl<max_pool_iq_t, max_pool_t, config34>(layer33_out, layer34_out); // max_pool

    nnet::concatenate1d<mean_pool_t, max_pool_t, concat0_t, config35>(layer32_out, layer34_out, layer35_out); // concat0

    nnet::concatenate1d<concat0_t, event_t, concat1_t, config37>(layer35_out, event, layer37_out); // concat1

    nnet::dense_da_39<concat1_t, head0_t>(layer37_out, layer39_out); // head0

    nnet::relu<head0_t, head0_relu_t, relu_config40>(layer39_out, layer40_out); // head0_relu

    nnet::dense_da_42<head0_relu_t, result_t>(layer40_out, layer42_out); // logit

}

