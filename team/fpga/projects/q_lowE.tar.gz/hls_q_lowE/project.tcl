variable project_name
set project_name "myproject"
variable backend
set backend "vitis"
variable part
set part "xcu200-fsgd2104-2-e"
variable clock_period
set clock_period 5.0
variable clock_uncertainty
set clock_uncertainty 27%
variable version
set version "1.0.0"
variable maximum_size
set maximum_size 4096
