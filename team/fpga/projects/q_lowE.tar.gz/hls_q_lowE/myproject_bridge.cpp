#ifndef MYPROJECT_BRIDGE_H_
#define MYPROJECT_BRIDGE_H_

#include "firmware/myproject.h"
#include "firmware/nnet_utils/nnet_helpers.h"
#include <algorithm>
#include <map>

// hls-fpga-machine-learning insert bram

namespace nnet {
bool trace_enabled = false;
std::map<std::string, void *> *trace_outputs = NULL;
size_t trace_type_size = sizeof(double);
} // namespace nnet

extern "C" {

struct trace_data {
    const char *name;
    void *data;
};

void allocate_trace_storage(size_t element_size) {
    nnet::trace_enabled = true;
    nnet::trace_outputs = new std::map<std::string, void *>;
    nnet::trace_type_size = element_size;
}

void free_trace_storage() {
    for (std::map<std::string, void *>::iterator i = nnet::trace_outputs->begin(); i != nnet::trace_outputs->end(); i++) {
        void *ptr = i->second;
        free(ptr);
    }
    nnet::trace_outputs->clear();
    delete nnet::trace_outputs;
    nnet::trace_outputs = NULL;
    nnet::trace_enabled = false;
}

void collect_trace_output(struct trace_data *c_trace_outputs) {
    int ii = 0;
    for (std::map<std::string, void *>::iterator i = nnet::trace_outputs->begin(); i != nnet::trace_outputs->end(); i++) {
        c_trace_outputs[ii].name = i->first.c_str();
        c_trace_outputs[ii].data = i->second;
        ii++;
    }
}

// hls-fpga-machine-learning insert tb_input_writer

// Wrapper of top level function for Python bridge
void myproject_float(
    float *particles, float *event,
    float *layer42_out
) {

    particles_t particles_ap[16*11];
    nnet::convert_data<float, particles_t, 16*11>(particles, particles_ap);
    event_t event_ap[11];
    nnet::convert_data<float, event_t, 11>(event, event_ap);

    result_t layer42_out_ap[1];

    myproject(particles_ap,event_ap,layer42_out_ap);

    nnet::convert_data<result_t, float, 1>(layer42_out_ap, layer42_out);
}

void myproject_double(
    double *particles, double *event,
    double *layer42_out
) {

    particles_t particles_ap[16*11];
    nnet::convert_data<double, particles_t, 16*11>(particles, particles_ap);
    event_t event_ap[11];
    nnet::convert_data<double, event_t, 11>(event, event_ap);

    result_t layer42_out_ap[1];

    myproject(particles_ap,event_ap,layer42_out_ap);

    nnet::convert_data<result_t, double, 1>(layer42_out_ap, layer42_out);
}
}

#endif
