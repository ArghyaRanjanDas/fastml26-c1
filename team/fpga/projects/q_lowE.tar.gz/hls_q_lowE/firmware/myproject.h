#ifndef MYPROJECT_H_
#define MYPROJECT_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "hls_stream.h"

#include "defines.h"


// Prototype of top level function for C-synthesis
void myproject(
    particles_t particles[16*11], event_t event[11],
    result_t layer42_out[1]
);

// hls-fpga-machine-learning insert emulator-defines


#endif
