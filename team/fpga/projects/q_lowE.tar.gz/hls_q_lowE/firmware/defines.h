#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <array>
#include <cstddef>
#include <cstdio>
#include <tuple>
#include <tuple>


// hls-fpga-machine-learning insert numbers

// hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<13,4> particles_t;
typedef ap_fixed<12,4> embed_iq_t;
typedef ap_fixed<19,9> embed_accum_t;
typedef ap_fixed<16,9> embed_t;
typedef ap_fixed<5,1> embed_bias_t;
typedef ap_fixed<12,5> embed_relu_t;
typedef ap_fixed<18,8> embed_relu_table_t;
typedef ap_fixed<5,5> mha0_query_iq_t;
typedef ap_fixed<11,7> mha0_query_accum_t;
typedef ap_fixed<5,5> mha0_query_t;
typedef ap_ufixed<2,32> mha0_query_bias_t;
typedef ap_fixed<5,5> mha0_query_oq_t;
typedef ap_fixed<5,5> mha0_key_iq_t;
typedef ap_fixed<10,6> mha0_key_accum_t;
typedef ap_fixed<5,4> mha0_key_t;
typedef ap_ufixed<2,32> mha0_key_bias_t;
typedef ap_fixed<4,4> mha0_key_oq_t;
typedef ap_fixed<6,6> mha0_value_iq_t;
typedef ap_fixed<11,7> mha0_value_accum_t;
typedef ap_fixed<7,4> mha0_value_t;
typedef ap_ufixed<2,32> mha0_value_bias_t;
typedef ap_fixed<6,4> mha0_value_oq_t;
typedef ap_fixed<8,8> mha0_mha0_QK_accum_t;
typedef ap_fixed<8,8> mha0_mha0_QK_t;
typedef ap_ufixed<1,0,AP_RND_CONV,AP_SAT,0> mha0_q_softmax_exp_table_t;
typedef ap_ufixed<1,-1,AP_RND_CONV,AP_SAT,0> mha0_q_softmax_inv_table_t;
typedef ap_fixed<1,0,AP_RND,AP_WRAP,0> mha0_q_softmax_inv_inp_t;
typedef ap_fixed<1,3,AP_RND,AP_SAT,0> mha0_q_softmax_inp_norm_t;
typedef ap_fixed<9,0> mha0_q_softmax_accum_t;
typedef ap_fixed<3,0> mha0_q_softmax_t;
typedef ap_fixed<18,8> mha0_q_softmax_table_t;
typedef ap_fixed<4,1> mha0_q_softmax_oq_t;
typedef ap_fixed<12,8> mha0_mha0_aV_accum_t;
typedef ap_fixed<5,3> mha0_mha0_aV_t;
typedef ap_fixed<4,3> mha0_attention_output_iq_t;
typedef ap_fixed<11,5> mha0_attention_output_accum_t;
typedef ap_fixed<7,1> mha0_attention_output_t;
typedef ap_fixed<7,1> mha0_attention_output_bias_t;
typedef ap_fixed<10,4> quantizer_t;
typedef ap_fixed<7,1> quantizer_1_t;
typedef ap_fixed<11,5> res_attn0_t;
typedef ap_fixed<8,5> mlp0_0_iq_t;
typedef ap_fixed<11,7> mlp0_0_accum_t;
typedef ap_fixed<8,7> mlp0_0_t;
typedef ap_ufixed<5,1> mlp0_0_bias_t;
typedef ap_fixed<7,6> mlp0_0_relu_t;
typedef ap_fixed<18,8> mlp0_0_relu_table_t;
typedef ap_fixed<6,6> mlp0_1_iq_t;
typedef ap_fixed<10,7> mlp0_1_accum_t;
typedef ap_fixed<9,6> mlp0_1_t;
typedef ap_fixed<4,1> mlp0_1_bias_t;
typedef ap_fixed<9,4> quantizer_2_t;
typedef ap_fixed<8,6> quantizer_3_t;
typedef ap_fixed<11,6> res_mlp0_t;
typedef ap_fixed<8,6> mean_pool_iq_t;
typedef ap_fixed<16,10> mean_pool_accum_t;
typedef ap_fixed<7,5> mean_pool_t;
typedef ap_fixed<10,6> max_pool_iq_t;
typedef ap_fixed<10,6> max_pool_accum_t;
typedef ap_fixed<6,5> max_pool_t;
typedef ap_fixed<7,5> concat0_t;
typedef ap_fixed<11,5> event_t;
typedef ap_fixed<11,5> concat1_t;
typedef ap_fixed<18,8> head0_accum_t;
typedef ap_fixed<13,8> head0_t;
typedef ap_uint<1> layer39_index;
typedef ap_fixed<11,6> head0_relu_t;
typedef ap_fixed<18,8> head0_relu_table_t;
typedef ap_fixed<18,8> logit_accum_t;
typedef ap_fixed<18,8> result_t;
typedef ap_uint<1> layer42_index;

// hls-fpga-machine-learning insert emulator-defines


#endif
